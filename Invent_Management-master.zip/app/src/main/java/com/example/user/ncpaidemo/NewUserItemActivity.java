package com.example.user.ncpaidemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NewUserItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_ocr_in);
    }
}