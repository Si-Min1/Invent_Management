package com.example.user.ncpaidemo;

public class SelfOutActivity {
}
